import pygame
import random
import noise
import sqlite3

class Model():
    def __init__(self, row, col):
        self.row = row
        self.col = col
        self.id = random.randint(-1000, 5)
        self.f = 1.7
        self.percent = random.randint(0, 10)

    def create_map(self):
        map = []
        for i in range(self.row):
            child_map = []
            for j in range(self.col):
                x = i / self.row
                y = j / self.col
                child_map.append(noise.snoise2(x * self.f, y * self.f, base=self.id))
            map.append(child_map)
        self.new_map = []
        for k in range(len(map)):
            new_map_child = []
            for n in range(len(map[k])):
                if map[k][n] < 0.2:
                    new_map_child.append(1)
                elif map[k][n] < 0.5:
                    new_map_child.append(3)
                elif map[k][n] < 0.8:
                    new_map_child.append(5)
                elif map[k][n] < 0.4:
                    new_map_child.append(4)
                elif map[k][n] < 0.9 or self.percent <= 2:
                    new_map_child.append(6)
                else:
                    new_map_child.append(2)
            self.new_map.append(new_map_child)
        return self.new_map

    def get_map(self, index, sizing):
        map = []
        for i in range(index[0], index[0]+sizing+1):
            child_map = []
            for j in range(index[1], index[1]+sizing+1):
                child_map.append(self.new_map[i][j])
            map.append(child_map)
        return map

    def save_map(self):
        id = random.randint(-1000, 1)
        bd = sqlite3.connect('map.db')
        cbd = bd.cursor()
        #cbd.execute("INSERT INTO 'map' VALUES (1)")
        cbd.execute("UPDATE 'map' SET id = " + str(id))
        bd.commit()

    def map(self):
        connect = sqlite3.connect('map.db')
        c = connect.cursor()
        c.execute("SELECT * FROM 'map'")
        #c.execute('CREATE TABLE IF NOT EXISTS "map" (id INTEGER)')
        rows = c.fetchall()
        self.id = rows[0][0]
        self.create_map()
