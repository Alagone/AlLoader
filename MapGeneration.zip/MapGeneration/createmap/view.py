import pygame

class Button:
    def __init__(self, screen, color, text, coord):
        self.coord = coord
        self.screen, self.color, self.text = screen, color, text
        self.rect = pygame.draw.rect(self.screen, self.color, (self.coord[0], self.coord[1], 300, 70))
        self.font = pygame.font.Font(None, 40)
        self.txt = self.font.render(self.text, True, (255, 255, 255))
        self.rectT = self.txt.get_rect()
        x, y = self.rect.x+self.rect.width//2, self.rect.y+self.rect.height//2
        self.rectT.center = x, y
        self.screen.blit(self.txt, self.rectT)

    def update(self):
        pygame.draw.rect(self.screen, self.color, (self.coord[0], self.coord[1], 300, 70))
        self.screen.blit(self.txt, self.rectT)

class View():
    def __init__(self, width, height, caption, row, col):
        self.screen = pygame.display.set_mode((width, height))
        icon = pygame.image.load("createmap/GenerMap.png")
        pygame.display.set_icon(icon)
        self.width = width
        self.height = height
        self.tile_width, self.tile_height = width//col, height//row
        self.saveBut = Button(self.screen, (255, 100, 0), 'Генерировать карту', (100, 10))
        self.loadBut = Button(self.screen, (0, 100, 255), 'Загрузить карту', (100, 100))

    def update(self, map):
        for i in range(len(map)):
            for j in range(len(map[i])):
                if map[i][j] == 1:
                    pygame.draw.rect(self.screen, (0, 130, 255),
                        (self.tile_width * i, self.tile_height * j, self.tile_width, self.tile_height))
                elif map[i][j] == 2:
                    pygame.draw.rect(self.screen, (70, 170, 255),
                    (self.tile_width * i, self.tile_height * j, self.tile_width, self.tile_height))
                elif map[i][j] == 3:
                    pygame.draw.rect(self.screen, (0, 255, 0),
                                     (self.tile_width * i, self.tile_height * j, self.tile_width, self.tile_height))
                elif map[i][j] == 4:
                    pygame.draw.rect(self.screen, (0, 160, 255),
                                     (self.tile_width * i, self.tile_height * j, self.tile_width, self.tile_height))
                elif map[i][j] == 5:
                    pygame.draw.rect(self.screen, (255, 150, 80),
                                     (self.tile_width * i, self.tile_height * j, self.tile_width, self.tile_height))
                elif map[i][j] == 6:
                    pygame.draw.rect(self.screen, (170, 170, 170),
                                     (self.tile_width * i, self.tile_height * j, self.tile_width, self.tile_height))


    def draw_map(self, map, sizing):
        for i in range(sizing):
            for j in range(sizing):
                if map[i][j] == 1:
                    pygame.draw.rect(self.screen, (0, 130, 255), (self.width//sizing * i, self.height//sizing * j, self.width//sizing, self.height//sizing))
                elif map[i][j] == 2:
                    pygame.draw.rect(self.screen, (70, 170, 255), (self.width//sizing * i, self.height//sizing * j, self.width//sizing, self.height//sizing))
                elif map[i][j] == 3:
                    pygame.draw.rect(self.screen, (0, 255, 0),
                                     (self.width//sizing * i, self.height//sizing * j, self.width//sizing, self.height//sizing))
                elif map[i][j] == 4:
                    pygame.draw.rect(self.screen, (0, 160, 255),
                                     (self.width//sizing * i, self.height//sizing * j, self.width//sizing, self.height//sizing))
                elif map[i][j] == 5:
                    pygame.draw.rect(self.screen, (255, 150, 80),
                                     (self.width//sizing * i, self.height//sizing * j, self.width//sizing, self.height//sizing))
                elif map[i][j] == 6:
                    pygame.draw.rect(self.screen, (170, 170, 170),
                                     (self.width//sizing * i, self.height//sizing * j, self.width//sizing, self.height//sizing))


    def menu(self, open):
        if open:
            Pys = pygame.surface.Surface((self.screen.get_width(), self.screen.get_height()))
            pygame.draw.rect(Pys, (0, 0, 0), (0, 0, Pys.get_width(), Pys.get_height()))
            Pys.set_alpha(110)
            self.screen.blit(Pys, (0, 0))

            self.saveBut.update()
            self.loadBut.update()
